
#include "main.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* Peripheral handles */
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* Prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);

/* ADXL345 */
#define ADXL_ADDR       (0x53U << 1)
#define ADXL_DEVID      0x00U
#define ADXL_FORMAT     0x31U
#define ADXL_POWER      0x2DU
#define ADXL_DATA       0x32U

/* DHT11 DATA pin: PA0 */
#define DHT_PORT GPIOA
#define DHT_PIN  GPIO_PIN_0

/* Live Expressions */
volatile int16_t x = 0, y = 0, z = 0;
volatile float ax = 0, ay = 0, az = 0;
volatile int16_t temperature = 0;
volatile int16_t humidity = 0;
volatile uint8_t sensor_ok = 0;
volatile uint8_t dht_ok = 0;
volatile uint8_t device_id = 0;
volatile uint32_t read_count = 0;
volatile uint32_t error_count = 0;

/* ---------- Microsecond timer using Cortex-M4 DWT ---------- */
static void delay_us_init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

static void delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (HAL_RCC_GetHCLKFreq() / 1000000U);

    while ((uint32_t)(DWT->CYCCNT - start) < ticks) {
    }
}

/* ---------- UART helpers ---------- */
static void uart_send(UART_HandleTypeDef *uart, const char *s)
{
    HAL_UART_Transmit(uart, (uint8_t *)s,
                      (uint16_t)strlen(s), 1000);
}

/* ---------- ADXL345 ---------- */
static uint8_t adxl_init(void)
{
    uint8_t v = 0;

    if (HAL_I2C_Mem_Read(&hi2c1, ADXL_ADDR, ADXL_DEVID,
                         I2C_MEMADD_SIZE_8BIT, &v, 1, 100) != HAL_OK)
        return 0;

    device_id = v;
    if (v != 0xE5U) return 0;

    v = 0x08U;  /* Full resolution, +/-2g */
    if (HAL_I2C_Mem_Write(&hi2c1, ADXL_ADDR, ADXL_FORMAT,
                          I2C_MEMADD_SIZE_8BIT, &v, 1, 100) != HAL_OK)
        return 0;

    v = 0x08U;  /* Measurement mode */
    if (HAL_I2C_Mem_Write(&hi2c1, ADXL_ADDR, ADXL_POWER,
                          I2C_MEMADD_SIZE_8BIT, &v, 1, 100) != HAL_OK)
        return 0;

    return 1;
}

static uint8_t adxl_read(int16_t *px, int16_t *py, int16_t *pz)
{
    uint8_t b[6];

    if (HAL_I2C_Mem_Read(&hi2c1, ADXL_ADDR, ADXL_DATA,
                         I2C_MEMADD_SIZE_8BIT, b, 6, 100) != HAL_OK)
        return 0;

    *px = (int16_t)((uint16_t)b[1] << 8 | b[0]);
    *py = (int16_t)((uint16_t)b[3] << 8 | b[2]);
    *pz = (int16_t)((uint16_t)b[5] << 8 | b[4]);
    return 1;
}

/* ---------- DHT11 GPIO direction ---------- */
static void dht_output_open_drain(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin = DHT_PIN;
    g.Mode = GPIO_MODE_OUTPUT_OD;
    g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DHT_PORT, &g);
}

static void dht_input(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin = DHT_PIN;
    g.Mode = GPIO_MODE_INPUT;
    g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DHT_PORT, &g);
}

/* Wait for pin to reach a level, with timeout in microseconds */
static uint8_t dht_wait_level(GPIO_PinState level, uint32_t timeout_us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t limit = timeout_us *
                     (HAL_RCC_GetHCLKFreq() / 1000000U);

    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) != level) {
        if ((uint32_t)(DWT->CYCCNT - start) > limit)
            return 0;
    }
    return 1;
}

/* Read DHT11: returns 1 on success */
static uint8_t dht_read(int16_t *t, int16_t *h)
{
    uint8_t data[5] = {0};

    /* Start signal: hold DATA low for at least 18 ms */
    dht_output_open_drain();
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_RESET);
    HAL_Delay(20);

    /* Release line and wait for sensor response */
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_SET);
    dht_input();
    delay_us(30);

    if (!dht_wait_level(GPIO_PIN_RESET, 100)) return 0;
    if (!dht_wait_level(GPIO_PIN_SET, 100)) return 0;
    if (!dht_wait_level(GPIO_PIN_RESET, 100)) return 0;

    /* 40 bits: each bit begins low, then a short or long high pulse */
    for (int i = 0; i < 40; i++) {
        if (!dht_wait_level(GPIO_PIN_SET, 100)) return 0;

        delay_us(40);

        data[i / 8] <<= 1;
        if (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET)
            data[i / 8] |= 1U;

        if (!dht_wait_level(GPIO_PIN_RESET, 100)) return 0;
    }

    /* Check checksum */
    if ((uint8_t)(data[0] + data[1] + data[2] + data[3]) != data[4])
        return 0;

    *h = data[0];
    *t = data[2];
    return 1;
}

/* ---------- MAIN ---------- */
int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_USART1_UART_Init();
    MX_USART2_UART_Init();

    delay_us_init();

    HAL_Delay(1000);

    sensor_ok = adxl_init();

    uart_send(&huart2, "\r\nSTM32 sensor monitoring started\r\n");

    if (sensor_ok) {
        uart_send(&huart2, "ADXL345 initialized\r\n");
    } else {
        uart_send(&huart2, "ADXL345 initialization failed\r\n");
    }

    while (1) {
        int16_t rx, ry, rz;
        int16_t t, h;
        char msg[180];

        if (sensor_ok && adxl_read(&rx, &ry, &rz)) {
            x = rx; y = ry; z = rz;
            ax = rx * 0.0039f;
            ay = ry * 0.0039f;
            az = rz * 0.0039f;
            read_count++;
        } else {
            error_count++;
            sensor_ok = adxl_init();
        }

        /* DHT11 needs at least about 1 second between reads */
        if (dht_read(&t, &h)) {
            temperature = t;
            humidity = h;
            dht_ok = 1;
        } else {
            dht_ok = 0;
            error_count++;
        }

        /*
         * Protocol sent to ESP32:
         * T=25,H=60,X=12,Y=-20,Z=250
         */
        if (sensor_ok && dht_ok) {
            snprintf(msg, sizeof(msg),
                     "T=%d,H=%d,X=%d,Y=%d,Z=%d\r\n",
                     (int)temperature, (int)humidity,
                     (int)x, (int)y, (int)z);

            uart_send(&huart1, msg);
            uart_send(&huart2, msg);
        } else {
            snprintf(msg, sizeof(msg),
                     "Sensor status: ADXL=%u DHT11=%u ID=0x%02X\r\n",
                     sensor_ok, dht_ok, device_id);
            uart_send(&huart2, msg);
        }

        /* DHT11 should not be polled too frequently */
        HAL_Delay(1000);
    }
}

/* ---------- CLOCK ---------- */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    osc.HSIState = RCC_HSI_ON;
    osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    osc.PLL.PLLM = 16;
    osc.PLL.PLLN = 336;
    osc.PLL.PLLP = RCC_PLLP_DIV4;
    osc.PLL.PLLQ = 4;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) Error_Handler();

    clk.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                    RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV2;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK)
        Error_Handler();
}

/* ---------- I2C1 ---------- */
static void MX_I2C1_Init(void)
{
    hi2c1.Instance = I2C1;
    hi2c1.Init.ClockSpeed = 100000;
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK) Error_Handler();
}

/* ---------- USART1: STM32 to ESP32 ---------- */
static void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) Error_Handler();
}

/* ---------- USART2: PC debugging ---------- */
static void MX_USART2_UART_Init(void)
{
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

/* ---------- GPIO ---------- */
static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* PA0 is reconfigured by the DHT11 driver */
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}
